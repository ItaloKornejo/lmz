export interface ICourse {
    id?: number,
    name: string,
    creation: Date,
    status: number
}