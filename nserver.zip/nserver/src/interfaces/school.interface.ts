export interface ISchool {
    id?: number,
    name: string,
    type: string,
    creation: Date,
    status: number
} 