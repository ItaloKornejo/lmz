export interface IClassroom {
    id?: number,
    name: string,
    grade: string,
    creation: Date,
    status: number
}