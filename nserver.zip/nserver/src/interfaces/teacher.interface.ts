export interface ITeacher {
    id?: number,
    name: string,
    lastname: string,
    creation: Date,
    status: number,
    idSchool: number,
    idCourse: number
}