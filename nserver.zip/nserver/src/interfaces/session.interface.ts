export interface ISession {
    id?: number,
    name: string,
    ini: Date,
    end: Date,
    creation: Date,
    status: number
} 