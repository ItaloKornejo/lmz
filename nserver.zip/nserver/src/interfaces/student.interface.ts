export interface IStudent {
    id?: number,
    name: string,
    lastname: string,
    phone:number
    creation: Date,
    status: number,
    idClassroom: number,
    idSchool: number
}